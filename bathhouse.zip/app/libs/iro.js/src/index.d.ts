// see rollup.config.js replace plugin
declare const VERSION: string;
declare const PROD: boolean;
declare const DEV_SERVER: boolean;